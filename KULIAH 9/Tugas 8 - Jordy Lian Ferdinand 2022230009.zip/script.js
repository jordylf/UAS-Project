$('body').append(`<div class="--tagline"><a href="https://www.instagram.com/jordyy.lf/" target="_blank">#JordyMadeThis</a></div>`);
        alert("Selamat Datang Di Website Jordy!");
        window.alert("Tolong Isi Formulir Dibawah Ini");

